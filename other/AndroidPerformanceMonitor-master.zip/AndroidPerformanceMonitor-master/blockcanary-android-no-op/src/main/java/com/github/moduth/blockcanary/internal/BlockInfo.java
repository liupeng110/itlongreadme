package com.github.moduth.blockcanary.internal;

public class BlockInfo {
}
